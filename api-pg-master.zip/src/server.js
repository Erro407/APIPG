import app from './app'
import { resolve } from 'path'

app.listen(process.env.PORT || 3333)