import Queue from './lib/Queue'
import './database'

Queue.processQueue()