# entrypoint.sh

yarn sequelize db:migrate
yarn start